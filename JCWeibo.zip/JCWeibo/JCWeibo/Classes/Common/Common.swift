//
//  Common.swift
//  JCWeibo
//
//  Created by leqiang222 on 2017/3/1.
//  Copyright © 2017年 com.leqiang222. All rights reserved.
//

import Foundation

let JCLoginSuccessNotification = "__loginSuccessNotification__"

let JC_Base_URL = "https://api.weibo.com/"
