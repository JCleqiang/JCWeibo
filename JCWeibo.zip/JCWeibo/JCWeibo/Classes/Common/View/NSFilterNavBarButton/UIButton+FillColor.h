//
//  UIButton+FillColor.h
//  手势block
//
//  Created by admin on 16/6/17.
//  Copyright © 2016年 静持大师. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (FillColor)
- (void)kl_setBackgroundColor:(UIColor *)backgroundColor forState:(UIControlState)state ;
@end
