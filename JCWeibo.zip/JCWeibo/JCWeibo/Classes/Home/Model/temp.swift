 // 一条微博
 /*
  "favorited": false,
  "created_at": "Wed Mar 01 23:19:37 +0800 2017",
  "id": 4080630453275615,
  "truncated": false,
  "in_reply_to_screen_name": "",
  "isLongText": false,
  "is_show_bulletin": 2,
  "pic_urls": [ ],
  "text": "给医生的话。穷人就不要恶宰了，富人适当宰一下，例如内环线的房东。 ​",
  "idstr": "4080630453275615",
  "gif_ids": "",
  "textLength": 64,
  "source_type": 2,
  "hasActionTypeCard": 0,
  "geo": null,
  "hot_weibo_tags": [ ],
  "user": {},
  "text_tag_tips": [ ],
  "comments_count": 2,
  "source": "",
  "source_allowclick": 0,
  "biz_feature": 0,
  "annotations": [],
  "positive_recom_flag": 0,
  "visible": {},
  "in_reply_to_status_id": "",
  "mid": "4080630453275615",
  "reposts_count": 0,
  "mlevel": 0,
  "attitudes_count": 5,
  "darwin_tags": [ ],
  "rid": "0_0_1_2775563490525377827",
  "userType": 0,
  "in_reply_to_user_id": ""
  */
 
 
 // 用户
 /*
  "cover_image_phone": "http://ww1.sinaimg.cn/crop.0.0.640.640.640/549d0121tw1egm1kjly3jj20hs0hsq4f.jpg",
  "id": 1565668374,
  "bi_followers_count": 44,
  "urank": 37,
  "profile_image_url": "http://tva1.sinaimg.cn/crop.0.0.768.768.50/5d523416jw8f8n48yv1dsj20lc0lc419.jpg",
  "class": 1,
  "verified_contact_email": "",
  "province": "100",
  "ability_tags": "经济政策",
  "verified": true,
  "url": "",
  "statuses_count": 22356,
  "geo_enabled": false,
  "follow_me": false,
  "description": "请粉丝谨慎发言，莫谈国事，不谈房价。",
  "followers_count": 536200,
  "verified_contact_mobile": "",
  "location": "其他",
  "mbrank": 6,
  "avatar_large": "http://tva1.sinaimg.cn/crop.0.0.768.768.180/5d523416jw8f8n48yv1dsj20lc0lc419.jpg",
  "star": 0,
  "verified_trade": "957",
  "profile_url": "u/1565668374",
  "weihao": "",
  "online_status": 0,
  "verified_contact_name": "",
  "screen_name": "财上海",
  "verified_source_url": "",
  "pagefriends_count": 1,
  "name": "财上海",
  "verified_reason": "微博知名财经博主",
  "friends_count": 81,
  "insecurity": {
  "sexual_content": false
  */
 
 // annotations
 /*
  {
  "client_mblogid": "iPhone-5AFA1FCF-8876-4A42-9FAC-DBB2BFDDFB92",
  "shooting": 1
  },
  
  */
